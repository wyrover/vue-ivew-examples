module.exports = {
  lintOnSave: false,
};
